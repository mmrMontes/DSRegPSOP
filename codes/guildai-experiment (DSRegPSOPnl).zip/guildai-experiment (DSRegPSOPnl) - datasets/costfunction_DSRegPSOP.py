
import numpy as np
import warnings
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, mean_absolute_percentage_error
warnings.filterwarnings(action='ignore')
def evaluation(PSO):
    starins=[str(PSO.variables[i])+',' for i in range(len(PSO.variables))]
    call = ''.join(starins)
    exec('global '+ call[0:len(call)-1])
    
    cost =[]
    try:
        PSO.ffvalues[0]
    except:
        for i in range(len(PSO.variables)):
                exec(PSO.variables[i]+'='+'PSO.variables_values['+str(i)+']')
        PSO.ffvalues = PSO.equa
        PSO.ffvalues = np.nan_to_num(PSO.ffvalues,nan=0) 
    for i in range(PSO.n):
        punish1 =1E-10/np.abs(np.max(PSO.evaluation[i])-np.min(PSO.evaluation[i]))
        punish2 = 10000*np.abs((PSO.nlvls-1) - np.sum([1.0 if ('m'+str(j-1) in PSO.equation[i][j]) else 0.0 for j in range(1,PSO.nlvls)]))
        y_RELU = PSO.evaluation[i]
        y_RELU= np.maximum(0,y_RELU)
        cost.append(mean_squared_error(PSO.ffvalues,y_RELU)+punish1+punish2)
    cost=np.array(cost)
    return np.nan_to_num(cost,nan=np.inf)  

def deliver_result(PSO):
    starins=[str(PSO.variables[i])+',' for i in range(len(PSO.variables))]
    call = ''.join(starins)
    exec('global '+ call[0:len(call)-1])
    zd = PSO.ffvalues
    z2 = PSO.GBdata['Evaluation']
    z2_relu = np.maximum(0,z2)
    print("Best Cost Saved:",f"{PSO.GBdata['GB']:.10E}","r2",f"{r2_score(zd,z2):.4E}","MAE",f"{mean_absolute_error(zd,z2):.4E}","MAPE",f"{mean_absolute_percentage_error(zd,z2):.4E}","MSE",f"{mean_squared_error(zd,z2):.4E}")
    print("Best Equation Saved:", PSO.GBdata['Equation'])

    


    
    
    
    



