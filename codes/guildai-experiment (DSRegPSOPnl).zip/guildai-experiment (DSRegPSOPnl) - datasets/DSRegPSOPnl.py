import numpy as np
from pytictoc import TicToc
import costfunction_DSRegPSOP as f
from sklearn.metrics import r2_score, mean_squared_error, mean_absolute_error, mean_absolute_percentage_error
from sklearn.datasets import fetch_openml
from sklearn.preprocessing import MinMaxScaler
from sklearn.model_selection import KFold, train_test_split


class DSRegPSOPnl():
    def __init__(self,fun,nlvls,n_operators,n,Ll,Lu,c1,c2,Mmax,lambd,fdmax,fdmin,Smax,Smin,Sslimit,dseta,operators,variables,variables_values,numbers_posc,groups,equa,fevalmax,desiredGB):
        self.nlvls = nlvls
        self.operators = operators
        self.variables = variables
        self.variables_values = variables_values
        self.numbers_posc = numbers_posc
        self.n_operators = n_operators
        self.n_coefficients = n_operators+1
        self.groups = groups
        self.fun = fun
        self.equation = []
        self.evaluation = []
        self.best_equation=[]
        self.best_evaluation=[]
        self.ffvalues=[]
        self.Sslimit = Sslimit
        self.SSresets = 0
        self.desiredGB = desiredGB


        self.D = (self.groups*(self.n_operators+self.n_coefficients)+(self.groups-1))*self.nlvls
        self.n = n
        self.lambd = lambd
        self.Ll = Ll
        self.Lu = Lu
        self.c1 = c1
        self.c2 = c2
        self.Mmax = Mmax
        self.fdmax = fdmax
        self.fdmin = fdmin
        self.Smax  = Smax
        self.Smin = Smin
        self.dseta = dseta
        self.equa = equa
        self.last = False


            
    def pos2eq(self):
        self.equation = []
        variables_ini = self.variables.copy()
        
        for i in range(self.n):
            equationlvl = []
            for m in range(self.nlvls):
                id_operator = np.array(np.floor(((self.X-self.Ll)/(self.Lu-self.Ll))*(len(self.operators)-1)),dtype=int)
                id_variable = np.array(np.floor(((self.X-self.Ll)/(self.Lu-self.Ll))*(len(self.variables)-1+self.numbers_posc)),dtype=int)
                try:
                    for j in range(self.groups):
                        if j == 0:
                            partial_equaS = '('
                        elif partial_equaS[-1]!='(':
                            partial_equaS += '('      
                        partial_equa = []
                        Popen = False
                        for k in range(j*int(((self.D/self.nlvls)/self.groups))+int((self.D/nlvls))*m,(j+1)*int((self.D/nlvls)/self.groups)+int((self.D/nlvls))*m):
                            if ((k+1+j%2+m%2)%2==0):
                                partial_equa.append(self.operators[id_operator[i,k]])
                            else:
                                if id_variable[i,k]<len(self.variables):
                                    partial_equa.append(self.variables[id_variable[i,k]])
                                else:
                                    Lower_limit = self.Ll + len(self.variables)*((self.Lu-self.Ll)/(len(self.variables)+self.numbers_posc))
                                    Upper_limit = self.Lu
                                    num_val = ((self.X[i,k]-Lower_limit)/ (Upper_limit-Lower_limit))*(self.Lu-self.Ll)-self.Lu
                                    partial_equa.append(str(num_val)+'*b')
                        partial_equa = list(''.join(partial_equa))
                        
                        for l in range(len(partial_equa)):
                            if partial_equa[l] == 'P':
                                if Popen:
                                    if partial_equa[l-1] != 'C' and partial_equa[l-1] != 'S' and partial_equa[l-1] != 'E'and partial_equa[l-1] != 'Z' and partial_equa[l-1] != '?' :
                                        partial_equa[l] = partial_equa[l-1]
                                        partial_equa[l-1] = ')'
                                        Popen = False
                                    else:
                                        partial_equa[l] = partial_equa[l-2]
                                        partial_equa[l-2] = ')'
                                        partial_equa[l-1] = ' '
                                        Popen = False
                                elif not Popen:
                                    partial_equa[l] = '('
                                    Popen = True
                        if Popen:
                            partial_equa.append(')')
                        if j+1 < self.groups:
                            partial_equaS += (''.join(partial_equa)+')'+self.operators[id_operator[i,-j]]).replace('P','(')
                        else:
                            partial_equaS += (''.join(partial_equa)+')').replace('P','(')
                        partial_equaS = partial_equaS.replace('^','**').replace(' ','').replace('S(','b*np.sin(').replace('C(','b*np.cos(').replace('E(','b*np.exp(').replace('Z(','b*np.sum(').replace('?(','b*np.sqrt(')
                except:
                     partial_equaS = "b*np.inf"
                              
                equationlvl.append(partial_equaS)
                self.variables.append('m'+str(m))
                self.variables.append('m'+str(m))

            self.equation.append(equationlvl)
            self.variables = variables_ini.copy()                        

        
        

    def evaleq(self):
        self.evaluation = []
        variables_ini = self.variables.copy()
        for m in range(self.nlvls):
            self.variables.append('m'+str(m))
        starins=[str(self.variables[i])+',' for i in range(len(self.variables))]
        call = ''.join(starins)
        exec('global '+ call[0:len(call)-1])
        try:
            exec(self.variables[0]+'[0]')
        except:
            for i in range(len(self.variables)):
                exec(self.variables[i]+'='+'self.variables_values['+str(i)+']')
        self.evaluation = []
        for i in range(self.n):
            for m in range(self.nlvls):
                try:
                    exec('m'+str(m)+'='+self.equation[i][m][:])
                except:
                    exec('m'+str(m)+'=np.ones(self.variables_values[0].shape)*np.inf')        
            exec('self.evaluation.append(m'+str(self.nlvls-1)+')')
        self.evaluation = np.array(self.evaluation)
        self.evaluation = np.nan_to_num(self.evaluation,nan=0)
        self.variables = variables_ini.copy()
                   
    def start(self):
        LSui = self.lambd*(self.Lu-self.Ll)
        LSu = LSui
        LSl = -LSu
        w = self.Mmax/2
        self.X = np.random.uniform(self.Ll,self.Lu,(self.n,self.D))
        self.V = np.zeros(self.X.shape)
        self.fevalmax = fevalmax
        self.pos2eq()
        self.evaleq()
        self.C = f.evaluation(self)
        
        feval = self.n
        self.GPi = self.C
        self.Pi = self.X
        self.best_equation_i = self.equation
        self.best_evaluation_i = self.evaluation
        GBid = np.argmin(self.GPi)
        self.GB = self.GPi[GBid]
        self.PG = self.Pi[GBid]
        self.best_equation = self.best_equation_i[GBid]
        self.best_evaluation = self.best_evaluation_i[GBid]
        GB0 = self.GB
        Ss = self.Smin
        Sscounter = 0
        deltamax = np.max(np.abs(self.PG))*self.fdmax*self.GB
        deltamin = np.min(np.abs(self.PG))*self.fdmin*self.GB
        delta = deltamin
        it = 0
        self.GBlist = [[]]*int(fevalmax/n)
        self.GBlist[it] = self.GB 
        
        self.GBdata = {'GB':self.GB.copy(),'Position':self.PG.copy(),'Equation':self.best_equation,'Evaluation':self.best_evaluation.copy()}

        t = TicToc()
        t.tic()
        while feval+n <= fevalmax:
            R1 = np.random.random(self.X.shape)
            R2 = np.random.random(self.X.shape)
            totalMoment = ((delta/deltamax)+(Ss/self.Smax))
            self.V = (totalMoment)*w*self.V+self.c1*R1*(self.PG-self.X)+self.c2*R2*(self.Pi-self.X)
            self.V = np.clip(self.V, LSl,LSu)
            deltai = np.sum(np.absolute(self.X-self.PG),axis = 1)
            U = np.repeat((deltai < delta).reshape(self.n,1),self.D,axis = 1)
            psi = np.random.uniform(self.Ll,self.Lu,(self.n,self.D))
            self.X = (1-U)*(self.X+self.V)+U*psi
            self.X[self.X>self.Lu] = np.maximum(self.Ll,self.Lu+(self.Lu-self.X[self.X>self.Lu]))
            self.X[self.X<self.Ll] = np.minimum(self.Lu,self.Ll+self.Ll-self.X[self.X<self.Ll])
            self.X = np.clip(self.X, self.Ll,self.Lu)
            self.pos2eq()
            self.evaleq()
            self.C = f.evaluation(self)
            feval += self.n
            

            for ind in range(self.n):
                if self.C[ind] <= self.GPi[ind]:
                    self.GPi[ind] = self.C[ind]
                    self.Pi[ind,:] = self.X[ind,:]
                    self.best_equation_i[ind] = self.equation[ind]
                    self.best_evaluation_i[ind] = self.evaluation[ind]
                    if self.GPi[ind] <= self.GB:
                        self.GB = self.GPi[ind]
                        self.PG = self.Pi[ind,:]
                        self.best_equation = self.best_equation_i[ind][:]
                        self.best_evaluation = self.best_evaluation_i[ind]
                        if self.GB<=self.GBdata['GB']:
                            self.GBdata = {'GB':self.GB.copy(),'Position':self.PG.copy(),'Equation':self.best_equation,'Evaluation':self.best_evaluation.copy()}
                     
            
            it+=1
            self.GBlist[it] = self.GB  
            
            if self.GBdata['GB'] <= self.desiredGB:
                time = t.tocvalue()
         
                print("function:", f"{self.fun}")
                print("Dimensions:", f"{self.D}")
                print('Function Evaluations:',f"{feval}")
                print('delta:',f"{delta}")
                print('Ss',f"{Ss}")
                print('deltamax:',f"{deltamax}")
                print('deltamin:',f"{deltamin}")
                print('Total Moment:',f"{totalMoment*w}")
                print('LSu:',f"{LSu}")
                print('LSl:',f"{LSl}") 
                print('Sscounter:',Sscounter)
                print('SSresets:',self.SSresets)
                print('Current Best Cost:', f"{self.GB:10E}")
                print('Current Best Equation:', self.best_equation)
                print("r2:",f"{r2_score(self.ffvalues,self.best_evaluation)}")
                print("MAE:",f"{mean_absolute_error(self.ffvalues,self.best_evaluation)}")
                print("MAPE:",f"{mean_absolute_percentage_error(self.ffvalues,self.best_evaluation)}")
                print("MSE:",f"{mean_squared_error(self.ffvalues,self.best_evaluation)}")  
                print('Current Best Cost Saved:', f"{self.GBdata['GB']}")
                print('Current Best Equation Saved:', self.GBdata['Equation'])
                print("r2 saved:",f"{r2_score(self.ffvalues,self.GBdata['Evaluation'])}")
                print("MAE saved:",f"{mean_absolute_error(self.ffvalues,self.GBdata['Evaluation'])}")
                print("MAPE saved:",f"{mean_absolute_percentage_error(self.ffvalues,self.GBdata['Evaluation'])}")
                print("MSE saved:",f"{mean_squared_error(self.ffvalues,self.GBdata['Evaluation'])}")
                print('Time:',time)
                self.last= True
                break
            
            elif np.mod(it,100)==0:
                time = t.tocvalue()
               
                print("function:", f"{self.fun}")
                print("Dimensions:", f"{self.D}")
                print('Function Evaluations:',f"{feval}")
                print('delta:',f"{delta}")
                print('Ss',f"{Ss}")
                print('deltamax:',f"{deltamax}")
                print('deltamin:',f"{deltamin}")
                print('Total Moment:',f"{totalMoment*w}")
                print('LSu:',f"{LSu}")
                print('LSl:',f"{LSl}") 
                print('Sscounter:',Sscounter)
                print('SSresets:',self.SSresets)
                print('Current Best Cost:', f"{self.GB}")
                print('Current Best Equation:', self.best_equation)
                print("r2:",f"{r2_score(self.ffvalues,self.best_evaluation)}")
                print("MAE:",f"{mean_absolute_error(self.ffvalues,self.best_evaluation)}")
                print("MAPE:",f"{mean_absolute_percentage_error(self.ffvalues,self.best_evaluation)}")
                print("MSE:",f"{mean_squared_error(self.ffvalues,self.best_evaluation)}")  
                print('Current Best Cost Saved:', f"{self.GBdata['GB']}")
                print('Current Best Equation Saved:', self.GBdata['Equation'])
                print("r2 saved:",f"{r2_score(self.ffvalues,self.GBdata['Evaluation'])}")
                print("MAE saved:",f"{mean_absolute_error(self.ffvalues,self.GBdata['Evaluation'])}")
                print("MAPE saved:",f"{mean_absolute_percentage_error(self.ffvalues,self.GBdata['Evaluation'])}")
                print("MSE saved:",f"{mean_squared_error(self.ffvalues,self.GBdata['Evaluation'])}")
                
                print('Time:',time)
                
                
                
            if np.absolute(self.GB-GB0)<=dseta*self.GB:
                if delta<deltamax:
                    delta = delta+deltamax*Ss
                else:
                    delta = deltamin
                    if Ss>=Smax:
                        Ss = self.Smin
                        Sscounter += 1
                        
                        if Sscounter == self.Sslimit:

                            if self.GB<=self.GBdata['GB']:
                                self.GBdata = {'GB':self.GB.copy(),'Position':self.PG.copy(),'Equation':self.best_equation,'Evaluation':self.best_evaluation.copy()}
                            self.SSresets+=1

                            LSui = self.lambd*(self.Lu-self.Ll)
                            LSu = LSui
                            LSl = -LSu
                            w = self.Mmax/2
                            self.X = np.random.uniform(self.Ll,self.Lu,(self.n,self.D))
                            self.V = np.zeros(self.X.shape)
                            
                            self.pos2eq()
                            self.evaleq()
                            self.C = f.evaluation(self)
                            self.GPi = self.C
                            self.Pi = self.X
                            self.best_equation_i = self.equation
                            self.best_evaluation_i = self.evaluation
                            GBid = np.argmin(self.GPi)
                            self.GB = self.GPi[GBid]
                            self.PG = self.Pi[GBid]
                            self.best_equation = self.best_equation_i[GBid]
                            self.best_evaluation = self.best_evaluation_i[GBid]
                            GB0 = self.GB
                            Ss = self.Smin
                            Sscounter = 0
                            deltamax = np.max(np.abs(self.PG))*self.fdmax*self.GB
                            deltamin = np.min(np.abs(self.PG))*self.fdmin*self.GB
                            delta = deltamin
                    else:
                        Ss = Ss+self.Smin        
            else:
                delta = deltamin
                Ss = self.Smin
                Sscounter = 0

            deltamax = np.max(np.abs(self.PG))*fdmax*self.GB
            deltamin = np.min(np.abs(self.PG))*fdmin*self.GB
            LSu = (((delta/deltamax)+(Ss/self.Smax))/2)*(LSui)
            LSl = -LSu
            GB0 = self.GB
            t.tic()
        self.last= True

        



function = 1.0
nlvls = 1.0
n_operators= 1.0
groups = 1.0
numbers_posc = 2.0
n=5

c1=2.0
c2=2.0
Mmax=1.1
lambd=1.0
fdmax=1.0
fdmin=1.0
Smax=1.0
Smin=1.0
Sslimit = 1.0
dseta=1.0
fevalmax=2E6
desiredGB = 1E-10
Ll=-1
Lu=1


if function == 1.0:
    airfoil = fetch_openml(name='airfoil_self_noise', version= 1)
    df = airfoil.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-1].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -1].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))     
elif function== 2.0: 
    concrete = fetch_openml(name='Concrete_Data', version=1)
    df = concrete.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-1].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -1].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function== 3.0: 
    cooling = fetch_openml(name='energy_efficiency', version=1, target_column='Y2')
    df = cooling.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-2].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -1].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function == 4.0:
    heating = fetch_openml(name='energy_efficiency', version=1, target_column='Y1')
    df = heating.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-2].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -2].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function == 5.0:
    yacht = fetch_openml(name='yacht_hydrodynamics', version=1)
    df = yacht.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-1].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -1].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function == 6.0:
    geo1 = fetch_openml(name='GeographicalOriginalofMusic', version=1)
    df = geo1.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-2].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -2].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function == 7.0:
    geo2 = fetch_openml(name='GeographicalOriginalofMusic', version=1)
    df = geo2.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-2].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -1].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function == 8.0:
    tecator = fetch_openml(name='tecator', version=1)
    df = tecator.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-2].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:, -2].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function == 9.0:
    white_wine = fetch_openml(name='wine-quality-white', version=1)
    df = white_wine.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-1].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:,-1].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
elif function == 10.0:
    red_wine = fetch_openml(name='wine-quality-red', version=1)
    df = red_wine.frame
    X_scaler = MinMaxScaler()
    y_scaler = MinMaxScaler()
    Xor = df.iloc[:, :-1].values
    X = X_scaler.fit_transform(Xor)
    yor = df.iloc[:,-1].values
    y = y_scaler.fit_transform(yor.reshape(len(yor),1))
    

# equa = y
operators = ('/','/SP','/CP','/P','/?P','/EP','/ZP','-','-SP','-CP','-P','-?P','-EP','-ZP','+','+SP','+CP','+P','+?P','+EP','+ZP','*','*SP','*CP','*P','*?P','*EP','*ZP','^','^SP','^CP','^P','^?P','^EP','^ZP')
# variables = ['b','e','pi']
# e = np.exp(1)*np.ones(X[:,0].shape)
# b = np.ones(X[:,0].shape)
# pi = np.pi*np.ones(X[:,0].shape)
# variables_values = [b,e,pi]
# for i in range(X.shape[1]):
#     variables.append(f"X{i}")
#     exec(f"X{i}=X[:,{i}]")
#     exec(f"variables_values.append(X{i})")



# np.random.seed(0)
# DS1=DSRegPSOPnl(function,int(nlvls),int(n_operators),int(n),Ll,Lu,c1,c2,Mmax,lambd,fdmax,fdmin,Smax,Smin,int(Sslimit),dseta,operators,variables,variables_values,int(numbers_posc),int(groups),equa,fevalmax,desiredGB)
# DS1.start()


X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=42)


kf = KFold(n_splits=5)
kf.get_n_splits(X_train)
mselist = []
maelist= []
mapelist = []
r2list = []
for i, (train_index, test_index) in enumerate(kf.split(X_train)):

    X = X_train[train_index]
    y = y_train[train_index]
    equa = y
    variables = ['b','e','pi']
    
    e = np.exp(1)*np.ones(X[:,0].shape)
    b = np.ones(X[:,0].shape)
    pi = np.pi*np.ones(X[:,0].shape)
    variables_values = [b,e,pi]
    for i in range(X.shape[1]):
        variables.append(f"X{i}")
        exec(f"X{i}=X[:,{i}]")
        exec(f"variables_values.append(X{i})")

    DS1=DSRegPSOPnl(function,int(nlvls),int(n_operators),int(n),Ll,Lu,c1,c2,Mmax,lambd,fdmax,fdmin,Smax,Smin,int(Sslimit),dseta,operators,variables,variables_values,int(numbers_posc),int(groups),equa,fevalmax,desiredGB)
    DS1.start()


    X = X_train[test_index]
    y = y_train[test_index]
    
    variables = ['b','e','pi']

    e = np.exp(1)*np.ones(X[:,0].shape)
    b = np.ones(X[:,0].shape)
    pi = np.pi*np.ones(X[:,0].shape)
    variables_values = [b,e,pi]
    for i in range(X.shape[1]):
        variables.append(f"X{i}")
        exec(f"X{i}=X[:,{i}]")
        exec(f"variables_values.append(X{i})")
    for i in range(DS1.nlvls):
        exec('m'+str(i)+'='+DS1.best_equation[i])
        exec('M=np.maximum(0,m'+str(i)+')')
    yd = y[:,0]
    M = np.array(M)
    M = np.nan_to_num(M,nan=0)
    r2list.append(r2_score(yd,M))
    maelist.append(mean_absolute_error(yd,M))
    mapelist.append(mean_absolute_percentage_error(yd,M))
    mselist.append(mean_squared_error(yd,M))
    mean_r2 = np.mean(r2list)
    mean_mae = np.mean(maelist)
    mean_mape = np.mean(mapelist)
    mean_mse = np.mean(mselist)
    print("mean r2:",f"{mean_r2}")
    print("mean MAE:",f"{mean_mae}")
    print("mean MAPE:",f"{mean_mape}")
    print("mean MSE:",f"{mean_mse}")


